import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface ChatwootConversation {
  id: number;
  status: string;
  account_id: number;
  contact: {
    id: number;
    name: string;
    phone_number: string;
    email: string;
  };
  messages?: any[];
  created_at: string;
  updated_at: string;
}

serve(async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Get the API token from environment variables
    const token = Deno.env.get('CHATWOOT_API_TOKEN')
    if (!token) {
      console.error('CHATWOOT_API_TOKEN not configured')
      return new Response(
        JSON.stringify({ error: 'CHATWOOT_API_TOKEN not configured' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 500,
        }
      )
    }

    // Get inbox_id from query params
    const url = new URL(req.url)
    const inboxId = url.searchParams.get('inbox_id')
    const accountId = url.searchParams.get('account_id') || '1'

    // Build Chatwoot API URL
    const chatwootUrl = `https://chatwoot-chatwoot.l0vghu.easypanel.host/api/v1/accounts/${accountId}/conversations`
    const fullUrl = inboxId ? `${chatwootUrl}?inbox_id=${inboxId}` : chatwootUrl

    console.log('Fetching from Chatwoot:', fullUrl)

    // Fetch from Chatwoot API
    const chatwootRes = await fetch(fullUrl, {
      headers: {
        'api_access_token': token, // Usando o header correto
        'Content-Type': 'application/json',
      },
    })

    if (!chatwootRes.ok) {
      console.error('Chatwoot API error:', chatwootRes.status, chatwootRes.statusText)
      return new Response(
        JSON.stringify({ 
          error: `Chatwoot API error: ${chatwootRes.status} ${chatwootRes.statusText}` 
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: chatwootRes.status,
        }
      )
    }

    const data = await chatwootRes.json()

    // Return the data
    return new Response(
      JSON.stringify(data),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )
  } catch (error) {
    console.error('Error in chatwoot-conversations function:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})
