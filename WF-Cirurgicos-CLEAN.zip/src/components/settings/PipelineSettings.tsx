import { Card } from '@/components/ui/card';

export function PipelineSettings() {
  return (
    <div className="space-y-4">
      <p className="text-muted-foreground">Configurações de pipeline em desenvolvimento...</p>
    </div>
  );
}