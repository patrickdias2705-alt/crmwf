export function CustomFieldsSettings() {
  return (
    <div className="space-y-4">
      <p className="text-muted-foreground">Configurações de campos customizados em desenvolvimento...</p>
    </div>
  );
}