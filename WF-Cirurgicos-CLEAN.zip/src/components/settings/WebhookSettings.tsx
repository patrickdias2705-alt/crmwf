export function WebhookSettings() {
  return (
    <div className="space-y-4">
      <p className="text-muted-foreground">Configurações de webhook em desenvolvimento...</p>
    </div>
  );
}