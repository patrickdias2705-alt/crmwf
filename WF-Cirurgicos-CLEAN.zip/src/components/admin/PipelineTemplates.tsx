export function PipelineTemplates() {
  return (
    <div className="space-y-4">
      <p className="text-muted-foreground">Templates de pipeline em desenvolvimento...</p>
    </div>
  );
}