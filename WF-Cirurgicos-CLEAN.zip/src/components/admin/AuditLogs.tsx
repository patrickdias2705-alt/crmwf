export function AuditLogs() {
  return (
    <div className="space-y-4">
      <p className="text-muted-foreground">Logs de auditoria em desenvolvimento...</p>
    </div>
  );
}